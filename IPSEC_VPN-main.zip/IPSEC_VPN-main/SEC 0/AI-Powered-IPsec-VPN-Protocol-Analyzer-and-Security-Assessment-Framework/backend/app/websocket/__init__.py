"""Real-time WebSocket foundation."""
