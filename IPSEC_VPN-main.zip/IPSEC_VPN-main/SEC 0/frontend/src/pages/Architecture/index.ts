export { ArchitecturePage } from './ArchitecturePage';
