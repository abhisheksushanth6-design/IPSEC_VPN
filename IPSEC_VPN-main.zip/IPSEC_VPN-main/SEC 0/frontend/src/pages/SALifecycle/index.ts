export { SALifecyclePage } from './SALifecyclePage';
