export { VulnerabilitiesPage } from './VulnerabilitiesPage';
